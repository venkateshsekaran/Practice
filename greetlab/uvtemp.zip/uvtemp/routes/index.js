const mainRoutes = {
    authRoute: require('./authRoute'),
    adminRoute : require('./adminRoute'),
    common : require('./common'),
    clientRoute : require('./clientRoute')
}


module.exports = mainRoutes