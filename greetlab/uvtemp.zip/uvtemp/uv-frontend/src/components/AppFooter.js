import React from 'react'
import { Footer, Card, Button } from "react-bootstrap"

const AppFooter = () => {
    return (
        <h1>Footer</h1>
    )
}
export default AppFooter;