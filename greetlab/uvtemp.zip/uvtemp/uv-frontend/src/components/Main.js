import React from 'react'
import { Footer, Card, Button } from "react-bootstrap"

const Main = () => {
    return (
        <h1>main</h1>
    )
}
export default Main;