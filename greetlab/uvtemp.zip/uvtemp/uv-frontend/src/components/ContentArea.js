import React from 'react'

const ContentArea = ({ children }) => {
    return (
        <div className="contentArea">
            {children}
        </div>
    )
}
export default ContentArea;