import AdminLayout from "../components/AdminLayout"
import Gateway from "./Gateway"
const GatewayPage = () => {

    return (
           <AdminLayout>
           <Gateway/>
           </AdminLayout>
    )
}

export default GatewayPage;